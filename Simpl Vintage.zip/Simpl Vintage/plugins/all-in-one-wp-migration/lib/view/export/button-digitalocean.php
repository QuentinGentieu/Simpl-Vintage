<a href="https://servmask.com/products/digitalocean-spaces-extension" target="_blank"><?php _e( 'DigitalOcean', AI1WM_PLUGIN_NAME ); ?></a>
