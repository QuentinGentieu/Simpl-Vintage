<a href="https://servmask.com/products/digitalocean-spaces-extеnsion" target="_blank"><?php _e( 'DigitalOcean', AI1WM_PLUGIN_NAME ); ?></a>
